
import cpit380project.FileChooser;
import cpit380project.Picture;
import cpit380project.PictureFrame;
import cpit380project.Pixel;
import cpit380project.SimplePicture;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;
import java.util.function.IntPredicate;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.rmi.CORBA.*;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JColorChooser;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;
import static javax.swing.text.StyleConstants.Size;

public class PictureMenue extends javax.swing.JFrame {

    public PictureMenue() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        VerticalRefelection = new javax.swing.JButton();
        ScaleUp = new javax.swing.JButton();
        CropButton = new javax.swing.JButton();
        Convert2Grayscale = new javax.swing.JButton();
        orignalLabel = new javax.swing.JLabel();
        modifiedLabel = new javax.swing.JLabel();
        ChooseImage = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Clear = new javax.swing.JButton();
        gray2Binary = new javax.swing.JButton();
        BlendButton = new javax.swing.JButton();
        ScaleDown = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        RightRotation = new javax.swing.JButton();
        LeftRotation = new javax.swing.JButton();
        Rotate180 = new javax.swing.JButton();
        Rotate270 = new javax.swing.JButton();
        Rotate360 = new javax.swing.JButton();
        negate = new javax.swing.JButton();
        Sunset = new javax.swing.JButton();
        DiagonalReflectionB2T = new javax.swing.JButton();
        DiagonalRefelectionT2B = new javax.swing.JButton();
        VerticalRefelection4 = new javax.swing.JButton();
        Perform = new javax.swing.JButton();
        GreenTextField = new javax.swing.JTextField();
        BlueTextField = new javax.swing.JTextField();
        RedTextField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        WEdited = new javax.swing.JTextField();
        HEdited = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        HOrignal = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        WOriginal = new javax.swing.JTextField();
        COriginal = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        CEdited = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        redSlider = new javax.swing.JSlider();
        greenSlider = new javax.swing.JSlider();
        jLabel15 = new javax.swing.JLabel();
        blueSlider = new javax.swing.JSlider();
        drawButton = new javax.swing.JButton();
        collage = new javax.swing.JButton();
        AverageFilter = new javax.swing.JButton();
        MinFilter = new javax.swing.JButton();
        MaxFilter = new javax.swing.JButton();
        MedianFilter = new javax.swing.JButton();
        GaussianFilter = new javax.swing.JButton();
        edgeDetection = new javax.swing.JButton();
        redEyeB = new javax.swing.JButton();
        clearSliderButton = new javax.swing.JButton();
        backgroundSubB = new javax.swing.JButton();
        return_home = new javax.swing.JButton();
        HistogramDiagrambutton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 102));
        jLabel1.setText("Picture Editor");

        VerticalRefelection.setForeground(new java.awt.Color(0, 153, 153));
        VerticalRefelection.setText("Vertical Reflection ");
        VerticalRefelection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VerticalRefelectionActionPerformed(evt);
            }
        });

        ScaleUp.setForeground(new java.awt.Color(0, 153, 153));
        ScaleUp.setText("Scale Up");
        ScaleUp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ScaleUpActionPerformed(evt);
            }
        });

        CropButton.setForeground(new java.awt.Color(0, 153, 153));
        CropButton.setText("Copy & Crop");
        CropButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CropButtonActionPerformed(evt);
            }
        });

        Convert2Grayscale.setForeground(new java.awt.Color(0, 153, 153));
        Convert2Grayscale.setText("Convert to gray scale ");
        Convert2Grayscale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Convert2GrayscaleActionPerformed(evt);
            }
        });

        orignalLabel.setForeground(new java.awt.Color(255, 0, 0));
        orignalLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        orignalLabel.setText("Missing image");
        orignalLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                orignalLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                orignalLabelMouseEntered(evt);
            }
        });

        modifiedLabel.setForeground(new java.awt.Color(255, 0, 0));
        modifiedLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        modifiedLabel.setText("Missing image");
        modifiedLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                modifiedLabelMouseClicked(evt);
            }
        });

        ChooseImage.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        ChooseImage.setForeground(new java.awt.Color(255, 0, 0));
        ChooseImage.setText("Choose image");
        ChooseImage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChooseImageActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 153, 153));
        jLabel2.setText("Edited");

        jLabel3.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 153, 153));
        jLabel3.setText("Original");

        Clear.setForeground(new java.awt.Color(0, 153, 153));
        Clear.setText("Clear ");
        Clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearActionPerformed(evt);
            }
        });

        gray2Binary.setForeground(new java.awt.Color(0, 153, 153));
        gray2Binary.setText("gray to Binary");
        gray2Binary.setActionCommand("Gray to Binary");
        gray2Binary.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gray2BinaryActionPerformed(evt);
            }
        });

        BlendButton.setForeground(new java.awt.Color(0, 153, 153));
        BlendButton.setText("Blend");
        BlendButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BlendButtonActionPerformed(evt);
            }
        });

        ScaleDown.setForeground(new java.awt.Color(0, 153, 153));
        ScaleDown.setText("Scale Down");
        ScaleDown.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ScaleDownActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 137, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 135, Short.MAX_VALUE)
        );

        RightRotation.setForeground(new java.awt.Color(0, 153, 153));
        RightRotation.setText("Right Rotation");
        RightRotation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RightRotationActionPerformed(evt);
            }
        });

        LeftRotation.setForeground(new java.awt.Color(0, 153, 153));
        LeftRotation.setText("Left Rotation");
        LeftRotation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LeftRotationActionPerformed(evt);
            }
        });

        Rotate180.setForeground(new java.awt.Color(0, 153, 153));
        Rotate180.setText("Rotate 180");
        Rotate180.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Rotate180ActionPerformed(evt);
            }
        });

        Rotate270.setForeground(new java.awt.Color(0, 153, 153));
        Rotate270.setText("Rotate 270");
        Rotate270.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Rotate270ActionPerformed(evt);
            }
        });

        Rotate360.setForeground(new java.awt.Color(0, 153, 153));
        Rotate360.setText("Rotate 360");
        Rotate360.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Rotate360ActionPerformed(evt);
            }
        });

        negate.setForeground(new java.awt.Color(0, 153, 153));
        negate.setText("Negate");
        negate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                negateActionPerformed(evt);
            }
        });

        Sunset.setForeground(new java.awt.Color(0, 153, 153));
        Sunset.setText("Sunset");
        Sunset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SunsetActionPerformed(evt);
            }
        });

        DiagonalReflectionB2T.setForeground(new java.awt.Color(0, 153, 153));
        DiagonalReflectionB2T.setText("Diagonal Reflection 1 () T2B");
        DiagonalReflectionB2T.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DiagonalReflectionB2TActionPerformed(evt);
            }
        });

        DiagonalRefelectionT2B.setForeground(new java.awt.Color(0, 153, 153));
        DiagonalRefelectionT2B.setText("Diagonal Reflection 1 () T2B");
        DiagonalRefelectionT2B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DiagonalRefelectionT2BActionPerformed(evt);
            }
        });

        VerticalRefelection4.setForeground(new java.awt.Color(0, 153, 153));
        VerticalRefelection4.setText("Horizontal Reflection ");
        VerticalRefelection4.setToolTipText("");
        VerticalRefelection4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VerticalRefelection4ActionPerformed(evt);
            }
        });

        Perform.setForeground(new java.awt.Color(0, 153, 153));
        Perform.setText("Perfom ");
        Perform.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PerformActionPerformed(evt);
            }
        });

        RedTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RedTextFieldActionPerformed(evt);
            }
        });

        jLabel4.setText("R");

        jLabel5.setText("G");

        jLabel6.setText("B");

        WEdited.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WEditedActionPerformed(evt);
            }
        });

        HEdited.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HEditedActionPerformed(evt);
            }
        });

        jLabel7.setForeground(new java.awt.Color(255, 0, 0));
        jLabel7.setText("Details");

        jLabel8.setText("Height");

        jLabel9.setText("Width");

        jLabel10.setForeground(new java.awt.Color(255, 0, 0));
        jLabel10.setText("Details");

        jLabel11.setText("Height");

        HOrignal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HOrignalActionPerformed(evt);
            }
        });

        jLabel12.setText("Width");

        WOriginal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WOriginalActionPerformed(evt);
            }
        });

        COriginal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                COriginalActionPerformed(evt);
            }
        });

        jLabel13.setText("Color");

        jLabel14.setText("Color");

        redSlider.setMaximum(255);
        redSlider.setValue(0);
        redSlider.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                redSliderStateChanged(evt);
            }
        });
        redSlider.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                redSliderMouseDragged(evt);
            }
        });

        greenSlider.setMaximum(255);
        greenSlider.setValue(0);
        greenSlider.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                greenSliderStateChanged(evt);
            }
        });
        greenSlider.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                greenSliderMouseDragged(evt);
            }
        });

        jLabel15.setText("Enter +num to increase by or -num to decrease by");

        blueSlider.setMaximum(255);
        blueSlider.setValue(0);
        blueSlider.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                blueSliderStateChanged(evt);
            }
        });
        blueSlider.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                blueSliderMouseDragged(evt);
            }
        });

        drawButton.setText("Draw");
        drawButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drawButtonActionPerformed(evt);
            }
        });

        collage.setForeground(new java.awt.Color(0, 153, 153));
        collage.setText("collage");
        collage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                collageActionPerformed(evt);
            }
        });

        AverageFilter.setForeground(new java.awt.Color(0, 153, 153));
        AverageFilter.setText("Average Filter");
        AverageFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AverageFilterActionPerformed(evt);
            }
        });

        MinFilter.setForeground(new java.awt.Color(0, 153, 153));
        MinFilter.setText("Min Filter");
        MinFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MinFilterActionPerformed(evt);
            }
        });

        MaxFilter.setForeground(new java.awt.Color(0, 153, 153));
        MaxFilter.setText("Max Filter");
        MaxFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MaxFilterActionPerformed(evt);
            }
        });

        MedianFilter.setForeground(new java.awt.Color(0, 153, 153));
        MedianFilter.setText("Median Filter");
        MedianFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MedianFilterActionPerformed(evt);
            }
        });

        GaussianFilter.setForeground(new java.awt.Color(0, 153, 153));
        GaussianFilter.setText("Gaussian Filter");
        GaussianFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GaussianFilterActionPerformed(evt);
            }
        });

        edgeDetection.setForeground(new java.awt.Color(0, 153, 153));
        edgeDetection.setText("edge Detection");
        edgeDetection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edgeDetectionActionPerformed(evt);
            }
        });

        redEyeB.setForeground(new java.awt.Color(0, 153, 153));
        redEyeB.setText("Red eye");
        redEyeB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                redEyeBActionPerformed(evt);
            }
        });

        clearSliderButton.setForeground(new java.awt.Color(0, 153, 153));
        clearSliderButton.setText("ClearSlider");
        clearSliderButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearSliderButtonActionPerformed(evt);
            }
        });

        backgroundSubB.setForeground(new java.awt.Color(0, 153, 153));
        backgroundSubB.setText("background Subtraction");
        backgroundSubB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backgroundSubBActionPerformed(evt);
            }
        });

        return_home.setBackground(new java.awt.Color(255, 255, 255));
        return_home.setFont(new java.awt.Font("Lucida Grande", 1, 24)); // NOI18N
        return_home.setForeground(new java.awt.Color(0, 102, 102));
        return_home.setText("<");
        return_home.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                return_homeActionPerformed(evt);
            }
        });

        HistogramDiagrambutton.setForeground(new java.awt.Color(0, 153, 153));
        HistogramDiagrambutton.setText("Histogram");
        HistogramDiagrambutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HistogramDiagrambuttonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(return_home, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(608, 608, 608))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(modifiedLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(9, 9, 9)
                                        .addComponent(jLabel12))
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 1, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel10))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(10, 10, 10)
                                            .addComponent(jLabel11))
                                        .addComponent(HOrignal)
                                        .addComponent(WOriginal, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel13))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 256, Short.MAX_VALUE)
                                .addComponent(orignalLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(COriginal, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(412, 412, 412)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel8)
                                    .addComponent(HEdited, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9)
                                    .addComponent(WEdited, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel14)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(CEdited, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(104, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(gray2Binary)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(negate, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(48, 48, 48))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(ScaleDown)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(drawButton)
                                                .addGap(70, 70, 70))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addGap(25, 25, 25)
                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(jLabel2)
                                                            .addComponent(Convert2Grayscale)))
                                                    .addComponent(CropButton, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(0, 0, Short.MAX_VALUE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addGap(0, 0, Short.MAX_VALUE)
                                                        .addComponent(collage, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(ScaleUp, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 111, Short.MAX_VALUE)
                                                        .addComponent(Sunset, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addGap(48, 48, 48)))))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(RightRotation, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Rotate180, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Rotate270, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(LeftRotation, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Rotate360, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(101, 101, 101)
                                        .addComponent(jLabel3))
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel15)))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(34, 34, 34)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel5)
                                            .addComponent(jLabel4)
                                            .addComponent(jLabel6))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(RedTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(redSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(GreenTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(greenSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(clearSliderButton))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(BlueTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(blueSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(DiagonalRefelectionT2B, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(DiagonalReflectionB2T, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(VerticalRefelection, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(25, 25, 25)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(MaxFilter, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(MedianFilter, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(MinFilter, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(AverageFilter, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(GaussianFilter, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(backgroundSubB, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(redEyeB, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(HistogramDiagrambutton, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(edgeDetection, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(Perform)
                                        .addGap(630, 630, 630)))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(ChooseImage)
                                .addGap(83, 83, 83)
                                .addComponent(Clear))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(BlendButton, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(368, 368, 368)
                                .addComponent(VerticalRefelection4, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(return_home, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(gray2Binary)
                    .addComponent(Convert2Grayscale)
                    .addComponent(RightRotation)
                    .addComponent(VerticalRefelection)
                    .addComponent(AverageFilter)
                    .addComponent(GaussianFilter)
                    .addComponent(backgroundSubB))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(negate)
                    .addComponent(LeftRotation)
                    .addComponent(BlendButton)
                    .addComponent(VerticalRefelection4)
                    .addComponent(MinFilter)
                    .addComponent(edgeDetection))
                .addGap(53, 53, 53)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Rotate180)
                    .addComponent(Sunset)
                    .addComponent(ScaleUp)
                    .addComponent(DiagonalReflectionB2T)
                    .addComponent(MaxFilter)
                    .addComponent(HistogramDiagrambutton))
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(redEyeB)
                    .addComponent(MedianFilter)
                    .addComponent(DiagonalRefelectionT2B)
                    .addComponent(Rotate270)
                    .addComponent(drawButton)
                    .addComponent(ScaleDown))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Rotate360)
                            .addComponent(collage))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel15)
                        .addGap(8, 8, 8)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(RedTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel4))
                            .addComponent(redSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(greenSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(GreenTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(clearSliderButton))
                                .addGap(18, 18, 18)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(BlueTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel6))
                            .addComponent(blueSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(CropButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ChooseImage)
                            .addComponent(Clear))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(Perform)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(HOrignal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(WOriginal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(COriginal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(19, 19, 19))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(modifiedLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(orignalLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jLabel7)
                        .addGap(16, 16, 16)
                        .addComponent(jLabel8)
                        .addGap(18, 18, 18)
                        .addComponent(HEdited, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(WEdited, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(58, 58, 58)
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(CEdited, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CropButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CropButtonActionPerformed

        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image please", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            JFrame parent = new JFrame();
            JOptionPane.showMessageDialog(parent, "Please click on two points in the image");

            orignalLabel.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                    System.out.println("Clicked!");
                    System.out.println(e.getX());
                    System.out.println(e.getY());
                    numOfClicks++;
                    if (numOfClicks == 1) {
                        x1 = e.getX();
                        y1 = e.getY();
                    } else if (numOfClicks == 2) {
                        x2 = e.getX();
                        y2 = e.getY();
                        // call the crop method with both cordinates.
                        CropImage(x1, y1, x2, y2);
                        numOfClicks = 0;
                        orignalLabel.removeMouseListener(this);
                    }
                }
            });
        }
    }//GEN-LAST:event_CropButtonActionPerformed

    private void Convert2GrayscaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Convert2GrayscaleActionPerformed
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image please!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            pic.grayscale();
            updateIMG();
        }
    }//GEN-LAST:event_Convert2GrayscaleActionPerformed

    private void ChooseImageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChooseImageActionPerformed
        // TODO add your handling code here:

        JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
        jfc.setDialogTitle("Select an image");
        jfc.setAcceptAllFileFilterUsed(false);
        FileNameExtensionFilter filter = new FileNameExtensionFilter("PNG or JPG", "png", "jpg", "jpeg");
        jfc.addChoosableFileFilter(filter);

        int returnValue = jfc.showOpenDialog(null);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            System.out.println(jfc.getSelectedFile().getPath() + " is selected");
            imgName = jfc.getSelectedFile().getPath();

            R_Value = -1;
            G_Value = -1;
            B_Value = -1;
            pic = new Picture(imgName);
            sourcePicture = new Picture(imgName);
            Image img = (pic.getImage()).getScaledInstance(orignalLabel.getWidth(), orignalLabel.getHeight(), Image.SCALE_SMOOTH);;
            orignalLabel.setText("");
            orignalLabel.setIcon(new ImageIcon(img));
            updateIMG();

        }    }//GEN-LAST:event_ChooseImageActionPerformed

    private void ClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearActionPerformed
        // TODO add your handling code here:
        pic = new Picture(imgName);
        sourcePicture = new Picture(imgName);
        updateIMG();
    }//GEN-LAST:event_ClearActionPerformed

    private void VerticalRefelectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VerticalRefelectionActionPerformed
        // TODO add your handling code here:
        int source_y = 0;
        int target_y = pic.getHeight() - 1;
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image please!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            while (target_y > source_y) {
                for (int x = 0; x < pic.getWidth(); x++) {
                    Pixel source_Pixel = pic.getPixel(x, source_y);
                    Pixel target_Pixel = pic.getPixel(x, target_y);
                    target_Pixel.setColor(source_Pixel.getColor());
                }
                target_y--;
                source_y++;
            }
            updateIMG();
        }
    }//GEN-LAST:event_VerticalRefelectionActionPerformed

    private void gray2BinaryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gray2BinaryActionPerformed
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image ", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            String ThresholdValue = JOptionPane.showInputDialog(null, "Please Enter the size: ");
            try {
                // **get the value from the histogram**
                int threadshold = Integer.parseInt(ThresholdValue);
                pic = pic.gray2Binary(threadshold);
                updateIMG();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Please put integer only", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

    }//GEN-LAST:event_gray2BinaryActionPerformed

    private void BlendButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BlendButtonActionPerformed
        if (pic != null) {

            JFileChooser jFileChooser = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
            jFileChooser.showOpenDialog(jFileChooser);
            Picture picture_obj = new Picture(jFileChooser.getSelectedFile().getAbsolutePath());

            // fixed this.
            Pixel[] pic_1 = pic.getPixels();
            Pixel[] pic_2 = picture_obj.getPixels();
            int pic1 = (pic.getHeight() * pic.getWidth());
            int pic2 = (picture_obj.getHeight() * picture_obj.getWidth());
            Pixel[] smaller;
            if (pic1 < pic2) {
                smaller = pic.getPixels();
            } else {
                smaller = picture_obj.getPixels();
            }
            int i = 0;
            while (i < smaller.length) {
                //----Here we calc the Colors----
                int valueP1 = ((pic_1[i].getRed() + pic_2[i].getRed()) / 2);
                int valueP2 = ((pic_1[i].getGreen() + pic_2[i].getGreen()) / 2);
                int valueP3 = ((pic_1[i].getBlue() + pic_2[i].getBlue()) / 2);
                //----Here we calc avg for 2 pic----
                pic_1[i].setColor(new Color(valueP1, valueP2, valueP3));
                i++;
            }

            updateIMG();
        } else {
            JOptionPane.showMessageDialog(null, "Select an image !", "Error", JOptionPane.ERROR_MESSAGE);
        }

            }//GEN-LAST:event_BlendButtonActionPerformed

    private void ScaleUpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ScaleUpActionPerformed
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image please!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            pic = pic.scaleUp(2);
            updateIMG();
            pic.show();
    }//GEN-LAST:event_ScaleUpActionPerformed
    }

    private void ScaleDownActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ScaleDownActionPerformed
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image please!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            pic = pic.scaleDown(2);
            updateIMG();
        }
    }//GEN-LAST:event_ScaleDownActionPerformed

    private void RightRotationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RightRotationActionPerformed
        // TODO add your handling code here:
        if (pic != null) {
            pic = pic.rotateRight();
            updateIMG();
        } else {
            JOptionPane.showMessageDialog(null, "Select an image please!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_RightRotationActionPerformed

    private void LeftRotationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LeftRotationActionPerformed
        // TODO add your handling code here:
        if (pic != null) {
            pic = pic.rotateLeft();
            updateIMG();
        } else {
            JOptionPane.showMessageDialog(null, "Select an image please!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_LeftRotationActionPerformed

    private void Rotate180ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Rotate180ActionPerformed
        // TODO add your handling code here:
        if (pic != null) {
            pic = pic.rotate(180);
            updateIMG();
        } else {
            JOptionPane.showMessageDialog(null, "Select an image please!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_Rotate180ActionPerformed

    private void Rotate270ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Rotate270ActionPerformed
        // TODO add your handling code here:
        if (pic != null) {
            pic = pic.rotate(270);
            updateIMG();
        } else {
            JOptionPane.showMessageDialog(null, "Select an image please!", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_Rotate270ActionPerformed

    private void Rotate360ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Rotate360ActionPerformed
        // TODO add your handling code here:
        if (pic != null) {
            pic = pic.rotate(360);
            updateIMG();
        } else {
            JOptionPane.showMessageDialog(null, "Select an image please!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_Rotate360ActionPerformed

    private void negateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_negateActionPerformed
        // TODO add your handling code here:
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image please!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            pic.negate();
            updateIMG();
        }
    }//GEN-LAST:event_negateActionPerformed

    private void SunsetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SunsetActionPerformed
        // TODO add your handling code here:
        orignalP = pic.getPixels();
        int value = 0;
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image please!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {

            for (int i = 0; i < orignalP.length; i++) {
                value = orignalP[i].getBlue();
                orignalP[i].setBlue((int) (value * 0.7));
                value = orignalP[i].getGreen();
                orignalP[i].setGreen((int) (value * 0.7));
            }

            updateIMG();
        }
    }//GEN-LAST:event_SunsetActionPerformed

    private void DiagonalReflectionB2TActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DiagonalReflectionB2TActionPerformed
        // TODO add your handling code here:
        Pixel leftPixel = null;
        Pixel rightPixel = null;
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image please!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            for (int y = 1; y < pic.getHeight(); y++) {
                for (int x = 0; x < y; x++) {
                    leftPixel = pic.getPixel(x, y);
                    rightPixel = pic.getPixel(y, x);
                    rightPixel.setColor(leftPixel.getColor());
                }
            }
            updateIMG();
        }
    }//GEN-LAST:event_DiagonalReflectionB2TActionPerformed

    private void DiagonalRefelectionT2BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DiagonalRefelectionT2BActionPerformed
        // TODO add your handling code here:
        Pixel leftPixel = null;
        Pixel rightPixel = null;
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image please!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            for (int y = 1; y < pic.getHeight(); y++) {
                for (int x = 0; x < y; x++) {
                    rightPixel = pic.getPixel(x, y);
                    leftPixel = pic.getPixel(y, x);
                    rightPixel.setColor(leftPixel.getColor());
                }
            }
            updateIMG();
        }
    }//GEN-LAST:event_DiagonalRefelectionT2BActionPerformed

    private void VerticalRefelection4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VerticalRefelection4ActionPerformed
        // TODO add your handling code here:
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image please!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            for (int x = 0; x < pic.getHeight(); x++) {
                int target_x = pic.getWidth() - 1;
                int source_x = 0;
                while (target_x > source_x) {
                    Pixel source_Pixel = pic.getPixel(source_x, x);
                    Pixel target_Pixel = pic.getPixel(target_x, x);
                    target_Pixel.setColor(source_Pixel.getColor());
                    target_x--;
                    source_x++;
                }
            }
            updateIMG();
        }
    }//GEN-LAST:event_VerticalRefelection4ActionPerformed

    private void PerformActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PerformActionPerformed
        // TODO add your handling code here:
        double redPerc = Double.parseDouble((RedTextField.getText()));
        double greenPerc = Double.parseDouble((GreenTextField.getText()));
        double bluePerc = Double.parseDouble((BlueTextField.getText()));
        int redV, greenV, blueV;
        orignalP = pic.getPixels();
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image please!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            for (int i = 0; i < orignalP.length; i++) {
                redV = orignalP[i].getRed();
                greenV = orignalP[i].getGreen();
                blueV = orignalP[i].getBlue();
                orignalP[i].setRed((orignalP[i].getRed()) + (int) (redV * (redPerc / 100)));
                orignalP[i].setGreen((orignalP[i].getGreen()) + (int) (greenV * (greenPerc / 100)));
                orignalP[i].setBlue((orignalP[i].getBlue()) + (int) (blueV * (bluePerc / 100)));
            }
            updateIMG();
        }
    }//GEN-LAST:event_PerformActionPerformed

    private void HEditedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HEditedActionPerformed
        HEdited.setText("HIEGHT: " + pic.getHeight());
    }//GEN-LAST:event_HEditedActionPerformed

    private void WEditedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WEditedActionPerformed
        // TODO add your handling code here:
        WEdited.setText("WIDTH " + pic.getWidth());
    }//GEN-LAST:event_WEditedActionPerformed

    private void HOrignalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HOrignalActionPerformed
        // TODO add your handling code here:
        HOrignal.setText("HIEGHT: " + pic.getHeight());
    }//GEN-LAST:event_HOrignalActionPerformed

    private void WOriginalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WOriginalActionPerformed
        // TODO add your handling code here:
        WOriginal.setText("WIDTH: " + pic.getWidth());
    }//GEN-LAST:event_WOriginalActionPerformed

    private void orignalLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_orignalLabelMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_orignalLabelMouseEntered

    private void orignalLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_orignalLabelMouseClicked
        // TODO add your handling code here:
        HEdited.setText("" + evt.getY());
        WEdited.setText("" + evt.getX());
        CEdited.setText(pic.getPixel(evt.getX(), evt.getY()).getColor().toString());
    }//GEN-LAST:event_orignalLabelMouseClicked

    private void modifiedLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_modifiedLabelMouseClicked
        // TODO add your handling code here:
        HOrignal.setText("" + evt.getY());
        WOriginal.setText("" + evt.getX());
        COriginal.setText(pic.getPixel(evt.getX(), evt.getY()).getColor().toString());
    }//GEN-LAST:event_modifiedLabelMouseClicked

    private void redSliderMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_redSliderMouseDragged
        // TODO add your handling code here:
        int red = redSlider.getValue();
        Pixel[] pixels = pic.getPixels();
        for (Pixel pixel : pixels) {
            pixel.setRed(red);
        }
        updateIMG();
    }//GEN-LAST:event_redSliderMouseDragged

    private void greenSliderMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_greenSliderMouseDragged
        // TODO add your handling code here:
        int green = redSlider.getValue();
        Pixel[] pixels = pic.getPixels();
        for (Pixel pixel : pixels) {
            pixel.setGreen(green);
        }
        updateIMG();
    }//GEN-LAST:event_greenSliderMouseDragged

    private void blueSliderMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_blueSliderMouseDragged
        // TODO add your handling code here:
        int blue = redSlider.getValue();
        Pixel[] pixels = pic.getPixels();
        for (Pixel pixel : pixels) {
            pixel.setBlue(blue);
        }
        updateIMG();
    }//GEN-LAST:event_blueSliderMouseDragged

    private void redSliderStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_redSliderStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_redSliderStateChanged

    private void greenSliderStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_greenSliderStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_greenSliderStateChanged

    private void blueSliderStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_blueSliderStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_blueSliderStateChanged

    private void RedTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RedTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RedTextFieldActionPerformed

    private void drawButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drawButtonActionPerformed
        // TODO add your handling code here:
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image please", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            Graphics g;
            g = pic.getGraphics();
            int c1 = (int) (Math.random() * 255 - 1);
            int c2 = (int) (Math.random() * 255 - 1);
            int c3 = (int) (Math.random() * 255 - 1);
            g.setColor(new Color(c1, c2, c3));
            int x1 = (int) (Math.random() * pic.getWidth() - 1);
            int x2 = (int) (Math.random() * pic.getWidth() - 1);
            int y1 = (int) (Math.random() * pic.getHeight() - 1);
            int y2 = (int) (Math.random() * pic.getHeight() - 1);
            g.drawRect(x1, y1, x2, y2);
            updateIMG();
        }
    }//GEN-LAST:event_drawButtonActionPerformed

    private void collageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_collageActionPerformed

        pic.createCollage();
        updateIMG();

    }//GEN-LAST:event_collageActionPerformed

    private void AverageFilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AverageFilterActionPerformed
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image please", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            int[] A = new int[9];
            double sum = 0;
            int avg = 0;
            for (int i = 1; i < pic.getWidth() - 1; i++) {
                for (int j = 1; j < pic.getHeight() - 1; j++) {
                    A[0] = (int) pic.getPixel(i - 1, j - 1).getAverage();
                    A[1] = (int) pic.getPixel(i - 1, j).getAverage();
                    A[2] = (int) pic.getPixel(i - 1, j + 1).getAverage();
                    A[3] = (int) pic.getPixel(i, j - 1).getAverage();
                    A[4] = (int) pic.getPixel(i, j).getAverage();
                    A[5] = (int) pic.getPixel(i, j + 1).getAverage();
                    A[6] = (int) pic.getPixel(i + 1, j - 1).getAverage();
                    A[7] = (int) pic.getPixel(i + 1, j).getAverage();
                    A[8] = (int) pic.getPixel(i + 1, j + 1).getAverage();
                    sum = A[0] + A[1] + A[2] + A[3] + A[4] + A[5] + A[6] + A[7] + A[8];
                    avg = (int) (sum / 9);
                    pic.getPixel(i, j).setColor(new Color(avg, avg, avg));
                }

            }
            updateIMG();
        }
    }//GEN-LAST:event_AverageFilterActionPerformed

    private void MinFilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MinFilterActionPerformed
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image please", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            pic.MinFilter();
            updateIMG();
        }
    }//GEN-LAST:event_MinFilterActionPerformed

    private void MaxFilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MaxFilterActionPerformed
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image please", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            pic.MaxFilter();
            updateIMG();
        }
    }//GEN-LAST:event_MaxFilterActionPerformed

    private void MedianFilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedianFilterActionPerformed
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image please", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            int[] A = new int[9];
            for (int i = 1; i < pic.getWidth() - 1; i++) {
                for (int j = 1; j < pic.getHeight() - 1; j++) {
                    A[0] = (int) pic.getPixel(i - 1, j - 1).getAverage();
                    A[1] = (int) pic.getPixel(i - 1, j).getAverage();
                    A[2] = (int) pic.getPixel(i - 1, j + 1).getAverage();
                    A[3] = (int) pic.getPixel(i, j - 1).getAverage();
                    A[4] = (int) pic.getPixel(i, j).getAverage();
                    A[5] = (int) pic.getPixel(i, j + 1).getAverage();
                    A[6] = (int) pic.getPixel(i + 1, j - 1).getAverage();
                    A[7] = (int) pic.getPixel(i + 1, j).getAverage();
                    A[8] = (int) pic.getPixel(i + 1, j + 1).getAverage();
                    Arrays.sort(A);
                    pic.getPixel(i, j).setColor(new Color(A[4], A[4], A[4]));
                }

            }
            updateIMG();
        }
    }//GEN-LAST:event_MedianFilterActionPerformed

    private void GaussianFilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GaussianFilterActionPerformed
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image please", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            pic.GaussianFilter3x3();
            updateIMG();
        }


    }//GEN-LAST:event_GaussianFilterActionPerformed

    private void edgeDetectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edgeDetectionActionPerformed
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image ", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            String ThresholdValue = JOptionPane.showInputDialog(null, "Please Enter the Thresholding : ");
            try {
                // *get the value from the histogram*
                int threadshold = Integer.parseInt(ThresholdValue);
                pic.edgeDetection(threadshold);
                updateIMG();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Please put integer only", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_edgeDetectionActionPerformed

    private void redEyeBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_redEyeBActionPerformed
        // TODO add your handling code here:
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image please!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            JFrame parent = new JFrame();
            JOptionPane.showMessageDialog(parent, "Please click on two points in the image");

            orignalLabel.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                    System.out.println("Clicked!");
                    System.out.println(e.getX());
                    System.out.println(e.getY());
                    numOfClicks++;
                    if (numOfClicks == 1) {
                        x1 = e.getX();
                        y1 = e.getY();
                    } else if (numOfClicks == 2) {
                        x2 = e.getX();
                        y2 = e.getY();

                        double W = (pic.getWidth() * 1.00 / orignalLabel.getWidth());
                        double H = (pic.getHeight() * 1.00 / orignalLabel.getHeight());

                        x1 = (int) (W * x1);
                        x2 = (int) (W * x2);
                        y1 = (int) (H * y1);
                        y2 = (int) (H * y2);

                        Color newColor = JColorChooser.showDialog(null, "Choose New Color", Color.BLACK);
                        int threshold = Integer.parseInt(JOptionPane.showInputDialog("Threshold:"));
                        for (int i = y1; i < y2; i++) {
                            for (int j = x1; j < x2; j++) {
                                Pixel p = pic.getPixel(j, i);
                                //here we compare because get the different between Red color amd pxl .
                                if (p.colorDistance(Color.RED) < threshold) {
                                    p.setColor(newColor);
                                }
                            }
                        }
                        updateIMG();
                        numOfClicks = 0;
                        orignalLabel.removeMouseListener(this);
                    }
                }
            });
        }
    }//GEN-LAST:event_redEyeBActionPerformed

    private void clearSliderButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearSliderButtonActionPerformed
        // TODO add your handling code here:
        redSlider.setValue(0);
        greenSlider.setValue(0);
        blueSlider.setValue(0);
    }//GEN-LAST:event_clearSliderButtonActionPerformed

    private void backgroundSubBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backgroundSubBActionPerformed
        // TODO add your handling code here:
        if (pic != null) {
            JFileChooser FileChooser = new JFileChooser("C:\\Users\\alish\\Downloads\\SoMultimedia");
            int conf = JOptionPane.showConfirmDialog(null, "Choose new background image", "Choose New Background", JOptionPane.OK_CANCEL_OPTION);
            if (conf == 0) {
                int val = FileChooser.showOpenDialog(null);
                if (val == JFileChooser.APPROVE_OPTION) {
                    Picture newBackground = new Picture(FileChooser.getSelectedFile().getAbsolutePath());
                    if (newBackground.getHeight() >= pic.getHeight() && newBackground.getWidth() >= pic.getWidth()) {
                        Chromacky(newBackground);
                    } else {
                        JOptionPane.showMessageDialog(null, "New Background Size must be >= Picture Size", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Select an image please!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void Chromacky(Picture newBackground) {
        Pixel picPixel = null;
        Pixel newPixel = null;
        for (int i = 0; i < pic.getWidth(); i++) {
            for (int j = 0; j < pic.getHeight(); j++) {
                picPixel = pic.getPixel(i, j);
                newPixel = newBackground.getPixel(i, j);
                if (picPixel.colorDistance(Color.GREEN) < 160) {
                    picPixel.setColor(newPixel.getColor());
                }
            }
        }
        updateIMG();
    }//GEN-LAST:event_backgroundSubBActionPerformed

    private void return_homeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_return_homeActionPerformed
        MainMenue menu = new MainMenue();
        menu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_return_homeActionPerformed

    private void COriginalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_COriginalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_COriginalActionPerformed

    private void HistogramDiagrambuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HistogramDiagrambuttonActionPerformed
        // TODO add your handling code here:
        if (pic == null) {
            JOptionPane.showMessageDialog(null, "Select an image please", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            pic.grayscale();
            int k = 256;
            int[] h = new int[k];
            Pixel[] pixels = pic.getPixels();
            for (int i = 0; i < pixels.length; i++) {
                int a = pixels[i].getRed();
                h[a]++;

            }
            int ymin = 4;
            int xmin = 3;
            Picture finalpic = new Picture(pic.getWidth(), pic.getHeight());
            Graphics g = finalpic.getGraphics();
            for (int u = 1; u < h.length; u++) {
                g.setColor(Color.BLACK);
                g.drawLine(xmin++, ymin, xmin, h[u] / 3);
            }
            finalpic.rotate180();
            Picture p = finalpic.mirrorAllVertical();
            Picture pict = new Picture(finalpic.getWidth(), finalpic.getHeight());
            pict.crop(p, finalpic.getWidth(), 0, p.getWidth(), p.getHeight(), 0, 0);
            pict.show();
            updateIMG();
        }
    }//GEN-LAST:event_HistogramDiagrambuttonActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PictureMenue().setVisible(true);
            }
        });
    }

    //Variables for choose
    private static String imgName;
    private static int R_Value = -1;
    private static int G_Value = -1;
    private static int B_Value = -1;
    Pixel[] orignalP;

    //Variables for crop
    private static Picture pic;
    int numOfClicks = 0;
    int x1;
    int x2;
    int y1;
    int y2;
    private Picture sourcePicture;

    //Methods for crop
    private void CropImage(int x1, int y1, int x2, int y2) {

        double W = (pic.getWidth() * 1.00 / orignalLabel.getWidth());
        double H = (pic.getHeight() * 1.00 / orignalLabel.getHeight());

        x1 = (int) (W * x1);
        x2 = (int) (W * x2);
        y1 = (int) (H * y1);
        y2 = (int) (H * y2);

        Picture newPic = new Picture(sourcePicture.getWidth(), sourcePicture.getHeight());

        Pixel sourcePixel;
        Pixel targetPixel;

        for (int i = x1; i < x2; i++) {
            for (int j = y1; j < y2; j++) {
                sourcePixel = sourcePicture.getPixel(i, j);
                targetPixel = newPic.getPixel(i, j);
                targetPixel.setColor(sourcePixel.getColor());
            }

        }
        pic = newPic;
        updateIMG();

    }

    private void updateIMG() {
        Image img = (pic.getImage()).getScaledInstance(modifiedLabel.getWidth(), modifiedLabel.getHeight(), Image.SCALE_SMOOTH);;
        modifiedLabel.setText("");
        modifiedLabel.setIcon(new ImageIcon(img));
        //System.out.printf("R= %d,G= %d,B= %d \n", R_Value, G_Value, B_Value);
    }

    // method for scaling up    
    public Picture scaleUp(int numTimes) {
        Picture targetPicture = new Picture(this.getWidth() * numTimes, this.getHeight() * numTimes);
        Pixel sourcePixel = null;
        Pixel targetPixel = null;
        int targetX = 0;
        int targetY = 0;
        for (int sourceX = 0; sourceX < this.getWidth(); sourceX++) {
            for (int sourceY = 0; sourceY < this.getHeight(); sourceY++) {
                sourcePixel = pic.getPixel(sourceX, sourceY);
                for (int indexY = 0; indexY < numTimes; indexY++) {
                    for (int indexX = 0; indexX < numTimes; indexX++) {
                        targetX = sourceX * numTimes + indexX;
                        targetY = sourceY * numTimes + indexY;
                        targetPixel = targetPicture.getPixel(targetX, targetY);
                        targetPixel.setColor(sourcePixel.getColor());
                    }
                }
            }
        }
        return targetPicture;

    }

    // method for scaling down
    public Picture ScaleDown(int numTimes) {

        Picture targetPicture = new Picture(this.getWidth(), this.getHeight());
        Pixel sourcePixel = null;
        Pixel targetPixel = null;

        // loop through the source picture columns
        for (int sourceX = 0, targetX = 0; sourceX < targetPicture.getWidth(); sourceX += numTimes, targetX++) {

            for (int sourceY = 0, targetY = 0; sourceY < targetPicture.getHeight(); sourceY += numTimes, targetY++) {

                sourcePixel = pic.getPixel(sourceX, sourceY);

                targetPixel = targetPicture.getPixel(targetX, targetY);

                targetPixel.setColor(sourcePixel.getColor());

            }
        }

        return targetPicture;

    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AverageFilter;
    private javax.swing.JButton BlendButton;
    private javax.swing.JTextField BlueTextField;
    private javax.swing.JTextField CEdited;
    private javax.swing.JTextField COriginal;
    private javax.swing.JButton ChooseImage;
    private javax.swing.JButton Clear;
    private javax.swing.JButton Convert2Grayscale;
    private javax.swing.JButton CropButton;
    private javax.swing.JButton DiagonalRefelectionT2B;
    private javax.swing.JButton DiagonalReflectionB2T;
    private javax.swing.JButton GaussianFilter;
    private javax.swing.JTextField GreenTextField;
    private javax.swing.JTextField HEdited;
    private javax.swing.JTextField HOrignal;
    private javax.swing.JButton HistogramDiagrambutton;
    private javax.swing.JButton LeftRotation;
    private javax.swing.JButton MaxFilter;
    private javax.swing.JButton MedianFilter;
    private javax.swing.JButton MinFilter;
    private javax.swing.JButton Perform;
    private javax.swing.JTextField RedTextField;
    private javax.swing.JButton RightRotation;
    private javax.swing.JButton Rotate180;
    private javax.swing.JButton Rotate270;
    private javax.swing.JButton Rotate360;
    private javax.swing.JButton ScaleDown;
    private javax.swing.JButton ScaleUp;
    private javax.swing.JButton Sunset;
    private javax.swing.JButton VerticalRefelection;
    private javax.swing.JButton VerticalRefelection4;
    private javax.swing.JTextField WEdited;
    private javax.swing.JTextField WOriginal;
    private javax.swing.JButton backgroundSubB;
    private javax.swing.JSlider blueSlider;
    private javax.swing.JButton clearSliderButton;
    private javax.swing.JButton collage;
    private javax.swing.JButton drawButton;
    private javax.swing.JButton edgeDetection;
    private javax.swing.JButton gray2Binary;
    private javax.swing.JSlider greenSlider;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel modifiedLabel;
    private javax.swing.JButton negate;
    private javax.swing.JLabel orignalLabel;
    private javax.swing.JButton redEyeB;
    private javax.swing.JSlider redSlider;
    private javax.swing.JButton return_home;
    // End of variables declaration//GEN-END:variables
}
